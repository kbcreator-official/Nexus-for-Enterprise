MyTemplate
==========

Thank you for downloading MyTemplate.

Folder Structure:
-----------------
MyTemplate/
├── Documentation/   -> Template documentation
├── index.html       -> Main HTML file
├── assets/
│   ├── css/         -> CSS files
│   ├── js/          -> JavaScript files
│   ├── images/      -> Images used in the template
└── README.txt       -> This file

How to Use:
-----------
1. Unzip the package.
2. Open index.html in your browser to preview the template.
3. Customize index.html and assets/ files according to your project needs.

Browser Compatibility:
----------------------
- Google Chrome
- Mozilla Firefox
- Safari
- Microsoft Edge

Support:
--------
For any issues, please contact us through the marketplace support channel.
