// Main JS file
console.log('MyTemplate loaded');